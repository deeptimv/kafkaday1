package com.daimler.kafka.practitioner;

import java.util.Map;

import org.apache.kafka.clients.producer.Partitioner;
import org.apache.kafka.common.Cluster;

public class MessagePartitioner implements Partitioner{

	@Override
	public void configure(Map<String, ?> configs) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int partition(String topic, Object key, byte[] keyBytes, Object value, byte[] valueBytes, Cluster cluster) {
		// TODO Auto-generated method stub
		int partition = 4;
		String k = (String)key;
		if(k.equalsIgnoreCase("test1msg")) {
			partition=0;
		}else if(k.equalsIgnoreCase("test2msg")) {
			partition=1;
		}else if(k.equalsIgnoreCase("test3msg")) {
			partition=2;
		}else if(k.equalsIgnoreCase("test4msg")) {
			partition=3;
		}
		return partition;
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		
	}

}
