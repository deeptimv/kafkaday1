package com.daimler.kafka;

import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

import com.daimler.kafka.domain.Employee;
import com.daimler.kafka.serializer.EmployeeSerializer;

public class EmployeeSenderTest {

	public static void main(String[] args) {

		Properties prop = new Properties();
		prop.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9093");
		prop.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		prop.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, EmployeeSerializer.class.getName());
		KafkaProducer<String, Employee> kafkaProducer = new KafkaProducer<>(prop);
		
		Employee emp1 = new Employee(100, "abc", "dev");
		Employee emp2 = new Employee(101, "def", "test");
		
		ProducerRecord<String, Employee> producerRecord1 = new ProducerRecord<String, Employee>("emp-topic", "emp-1", emp1);
		kafkaProducer.send(producerRecord1);
		
		ProducerRecord<String, Employee> producerRecord2 = new ProducerRecord<String, Employee>("emp-topic", "emp-2", emp2);
		kafkaProducer.send(producerRecord2);


		System.out.println("messages sent");
		kafkaProducer.close();
	}

}
